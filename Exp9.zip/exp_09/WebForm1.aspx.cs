﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace exp_09
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpBrowserCapabilities browser = Request.Browser;

            // Display browser information using Response.Write
            Response.Write($"<p>Browser Type: {browser.Type}</p>");
            Response.Write($"<p>Browser Name: {browser.Browser}</p>");
            Response.Write($"<p>Browser Version: {browser.Version}</p>");
            Response.Write($"<p>Is Mobile Device: {browser.IsMobileDevice}</p>");
            Response.Write($"<p>Platform: {browser.Platform}</p>");
            Response.Write($"<p>Major Version: {browser.MajorVersion}</p>");
            Response.Write($"<p>Minor Version: {browser.MinorVersion}</p>");

            // You can also check for specific features
            bool supportsFrames = browser.Frames;
            bool supportsJavaScript = browser.EcmaScriptVersion.Major >= 1;
            bool supportsCookies = browser.Cookies;

            Response.Write($"<p>Supports Frames: {supportsFrames}</p>");
            Response.Write($"<p>Supports JavaScript: {supportsJavaScript}</p>");
            Response.Write($"<p>Supports 2: {browser.EcmaScriptVersion}</p>");
            Response.Write($"<p>Supports Cookies: {supportsCookies}</p>");

                   }

    }
}