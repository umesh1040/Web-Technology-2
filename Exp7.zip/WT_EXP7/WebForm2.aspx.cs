﻿using System;

namespace Exp2
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write(Application["ApplicationKey"]+"<br>");
            Response.Write(Session["SessionKey"] + "<br>");

            Response.Write((Request.Cookies["CookieKey"].Value) + "<br>");

            Response.Write(Request.QueryString["param"] + "<br>");
        }
    }
}