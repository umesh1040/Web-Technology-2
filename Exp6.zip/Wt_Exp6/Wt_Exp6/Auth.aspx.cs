﻿using System;

namespace Wt_Exp6
{
    public partial class Auth : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Image1.Visible = false;
            string isvalid = Application["isvalid"].ToString();
            if (isvalid.Equals("Yes"))
            {
                Image1.Visible = true;
            }
        }
    }
}