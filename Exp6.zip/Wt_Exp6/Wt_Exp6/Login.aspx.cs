﻿using System;
using System.Collections.Generic;

namespace Wt_Exp6
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            ErrorMessageLabel.Visible = false;
        }
        private Dictionary<string, string> validCredentials = new Dictionary<string, string>
        {
            {"Umesh", "123456"},
            {"Admin", "Admin@12345"},
        };
        protected void Button1_Click(object sender, EventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordTextBox.Text;

            if (validCredentials.ContainsKey(username) && validCredentials[username] == password)
            {
                Application["isvalid"] = "Yes";
                Response.Redirect("Auth.aspx");
            }
            else
            {
                ErrorMessageLabel.Visible = true;
                ErrorMessageLabel.Text = "Invalid username or password. Please try again.";
            }
        }
    }
    }
